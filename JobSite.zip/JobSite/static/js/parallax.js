// Mouse-based Parallax Effect for UNIJOB-BD

document.addEventListener('DOMContentLoaded', function() {
    // Initialize parallax on page load
    initParallax();
});

function initParallax() {
    const parallaxElements = document.querySelectorAll('.parallax-element');
    const parallaxBg = document.querySelectorAll('.parallax-bg');
    const cards = document.querySelectorAll('.card');
    const heroSection = document.querySelector('.hero-section');
    
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;
    
    // Track mouse movement
    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        // Calculate center of viewport
        const centerX = window.innerWidth / 2;
        const centerY = window.innerHeight / 2;
        
        // Calculate offset from center
        targetX = (mouseX - centerX) / centerX;
        targetY = (mouseY - centerY) / centerY;
    });
    
    // Apply parallax effect with smooth animation
    function animateParallax() {
        // Apply to parallax elements
        parallaxElements.forEach((element, index) => {
            const speed = 0.05 + (index * 0.02);
            const x = targetX * speed * 50;
            const y = targetY * speed * 50;
            element.style.transform = `translate(${x}px, ${y}px)`;
        });
        
        // Apply to background patterns
        parallaxBg.forEach((bg, index) => {
            const speed = 0.02 + (index * 0.01);
            const x = targetX * speed * 100;
            const y = targetY * speed * 100;
            bg.style.transform = `translate(${x}px, ${y}px)`;
        });
        
        // Apply subtle parallax to hero section
        if (heroSection) {
            const heroX = targetX * 0.03 * 30;
            const heroY = targetY * 0.03 * 30;
            heroSection.style.backgroundPosition = `${50 + heroX}% ${50 + heroY}%`;
        }
        
        // Apply parallax to cards on hover
        cards.forEach((card, index) => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;
                
                const moveX = (x - centerX) / centerX * 10;
                const moveY = (y - centerY) / centerY * 10;
                
                card.style.transform = `perspective(1000px) rotateY(${moveX * 0.5}deg) rotateX(${-moveY * 0.5}deg) translateY(-8px) scale(1.02)`;
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.transform = '';
            });
        });
        
        requestAnimationFrame(animateParallax);
    }
    
    // Start animation loop
    animateParallax();
    
    // Parallax on scroll (additional effect)
    let scrollY = 0;
    window.addEventListener('scroll', () => {
        scrollY = window.scrollY;
        
        // Apply scroll-based parallax to hero section
        if (heroSection) {
            const heroParallax = scrollY * 0.5;
            heroSection.style.transform = `translateY(${heroParallax}px)`;
        }
        
        // Parallax for sections
        document.querySelectorAll('section').forEach((section, index) => {
            const rect = section.getBoundingClientRect();
            const speed = 0.1 + (index * 0.05);
            
            if (rect.top < window.innerHeight && rect.bottom > 0) {
                const offset = (window.innerHeight - rect.top) * speed;
                section.style.transform = `translateY(${offset}px)`;
            }
        });
    });
    
    // Smooth parallax for stats cards
    const statsCards = document.querySelectorAll('.stats-card, .card');
    statsCards.forEach((card, index) => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const moveX = ((x - centerX) / centerX) * 15;
            const moveY = ((y - centerY) / centerY) * 15;
            
            card.style.transform = `translate(${moveX}px, ${moveY}px)`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translate(0, 0)';
        });
    });
}

// Add parallax classes to elements
document.addEventListener('DOMContentLoaded', function() {
    // Add parallax class to hero section
    const heroSection = document.querySelector('.hero-section');
    if (heroSection) {
        heroSection.classList.add('parallax-container');
        const heroContent = heroSection.querySelector('.container');
        if (heroContent) {
            heroContent.classList.add('parallax-element');
        }
    }
    
    // Add parallax background to sections
    document.querySelectorAll('section.bg-light, section.py-5').forEach((section, index) => {
        if (!section.querySelector('.parallax-bg')) {
            const bg = document.createElement('div');
            bg.classList.add('parallax-bg');
            section.style.position = 'relative';
            section.appendChild(bg);
        }
    });
});

