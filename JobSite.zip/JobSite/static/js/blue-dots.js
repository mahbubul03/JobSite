// Blue Dots Background Animation with Mouse Interaction

(function() {
    'use strict';

    class BlueDotsBackground {
        constructor() {
            this.dots = [];
            this.mouse = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
            this.targetMouse = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
            this.animationId = null;
            this.container = null;
            this.isRunning = false;
        }

        init() {
            this.container = document.querySelector('.hero-section');
            if (!this.container) {
                console.warn('Hero section not found');
                return;
            }

            // Initialize mouse position
            this.targetMouse.x = window.innerWidth / 2;
            this.targetMouse.y = window.innerHeight / 2;
            this.mouse.x = this.targetMouse.x;
            this.mouse.y = this.targetMouse.y;

            // Wait for container to be ready
            setTimeout(() => {
                this.createDots();
                this.bindEvents();
                this.animate();
                this.isRunning = true;
            }, 100);
        }

        createDots() {
            if (!this.container) return;

            // Clear existing dots
            this.dots.forEach(dot => {
                if (dot.element && dot.element.parentNode) {
                    dot.element.parentNode.removeChild(dot.element);
                }
            });
            this.dots = [];

            const dotCount = 80;
            const containerRect = this.container.getBoundingClientRect();
            const width = containerRect.width || window.innerWidth;
            const height = containerRect.height || window.innerHeight;

            for (let i = 0; i < dotCount; i++) {
                const element = document.createElement('div');
                element.className = 'blue-dot';
                
                // Random size
                const size = 3 + Math.random() * 4;
                element.style.width = size + 'px';
                element.style.height = size + 'px';
                element.style.borderRadius = '50%';
                
                // Blue color with variation
                const blueShades = [
                    '#4285F4',
                    '#5C9DFF',
                    '#2962FF',
                    '#1976D2',
                    '#2196F3'
                ];
                const color = blueShades[Math.floor(Math.random() * blueShades.length)];
                element.style.backgroundColor = color;
                
                // Opacity
                const baseOpacity = 0.4 + Math.random() * 0.4;
                element.style.opacity = baseOpacity;
                
                // Initial position
                const baseX = Math.random() * width;
                const baseY = Math.random() * height;
                
                const dot = {
                    element: element,
                    x: baseX,
                    y: baseY,
                    baseX: baseX,
                    baseY: baseY,
                    originalBaseX: baseX,
                    originalBaseY: baseY,
                    size: size,
                    baseOpacity: baseOpacity,
                    speed: 0.3 + Math.random() * 0.5,
                    offset: Math.random() * Math.PI * 2
                };

                element.style.left = dot.x + 'px';
                element.style.top = dot.y + 'px';
                element.style.position = 'absolute';

                this.container.appendChild(element);
                this.dots.push(dot);
            }
        }

        bindEvents() {
            // Mouse tracking - use document for better tracking
            const handleMouseMove = (e) => {
                if (!this.container) return;
                const rect = this.container.getBoundingClientRect();
                this.targetMouse.x = e.clientX - rect.left;
                this.targetMouse.y = e.clientY - rect.top;
            };

            document.addEventListener('mousemove', handleMouseMove);
            this.container.addEventListener('mousemove', handleMouseMove);

            // Window resize
            let resizeTimeout;
            window.addEventListener('resize', () => {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(() => {
                    this.createDots();
                }, 250);
            });
        }

        updateDot(dot, time) {
            const containerRect = this.container.getBoundingClientRect();
            const width = containerRect.width || window.innerWidth;
            const height = containerRect.height || window.innerHeight;

            // Smooth mouse interpolation - faster response
            this.mouse.x += (this.targetMouse.x - this.mouse.x) * 0.3;
            this.mouse.y += (this.targetMouse.y - this.mouse.y) * 0.3;

            // Calculate distance to mouse
            const dx = this.mouse.x - dot.x;
            const dy = this.mouse.y - dot.y;
            const distance = Math.sqrt(dx * dx + dy * dy);

            // Mouse influence - dots move away from mouse (stronger effect)
            const maxInfluence = 250;
            let mouseForceX = 0;
            let mouseForceY = 0;

            if (distance < maxInfluence && distance > 5) {
                const force = (maxInfluence - distance) / maxInfluence;
                const angle = Math.atan2(dy, dx);
                // Stronger push effect
                const pushStrength = force * 50;
                
                mouseForceX = -Math.cos(angle) * pushStrength;
                mouseForceY = -Math.sin(angle) * pushStrength;
            }

            // Smooth floating animation (circular motion) - smaller amplitude
            const floatX = Math.sin(time * dot.speed + dot.offset) * 15;
            const floatY = Math.cos(time * dot.speed + dot.offset) * 15;

            // Calculate new position with mouse influence
            // Base position returns to original gradually
            dot.baseX += (dot.originalBaseX - dot.baseX) * 0.05;
            dot.baseY += (dot.originalBaseY - dot.baseY) * 0.05;

            // Combine base position, float animation, and mouse influence
            dot.x = dot.baseX + floatX + mouseForceX;
            dot.y = dot.baseY + floatY + mouseForceY;

            // Keep dots within bounds
            dot.x = Math.max(0, Math.min(width, dot.x));
            dot.y = Math.max(0, Math.min(height, dot.y));

            // Update DOM position
            dot.element.style.left = dot.x + 'px';
            dot.element.style.top = dot.y + 'px';

            // Scale effect when near mouse (more noticeable)
            const scale = distance < 80 ? 2.0 : (distance < 120 ? 1.5 : (distance < 180 ? 1.2 : 1.0));
            dot.element.style.transform = `scale(${scale})`;

            // Opacity change when near mouse
            let opacity = dot.baseOpacity;
            if (distance < 80) {
                opacity = Math.min(1.0, dot.baseOpacity + 0.4);
            } else if (distance < 120) {
                opacity = Math.min(0.9, dot.baseOpacity + 0.3);
            } else if (distance < 180) {
                opacity = Math.min(0.8, dot.baseOpacity + 0.2);
            }
            dot.element.style.opacity = opacity;
        }

        animate() {
            if (!this.isRunning) return;

            const time = Date.now() * 0.001;

            // Update all dots
            this.dots.forEach(dot => {
                this.updateDot(dot, time);
            });

            this.animationId = requestAnimationFrame(() => this.animate());
        }

        destroy() {
            this.isRunning = false;
            if (this.animationId) {
                cancelAnimationFrame(this.animationId);
            }
            this.dots.forEach(dot => {
                if (dot.element && dot.element.parentNode) {
                    dot.element.parentNode.removeChild(dot.element);
                }
            });
            this.dots = [];
        }
    }

    // Initialize
    let blueDots = null;

    function init() {
        if (blueDots) {
            blueDots.destroy();
        }
        blueDots = new BlueDotsBackground();
        blueDots.init();
    }

    // Wait for DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Reinitialize on page show
    window.addEventListener('pageshow', (e) => {
        if (e.persisted) {
            setTimeout(init, 100);
        }
    });

})();
