// Enhanced Antigravity Effect - Google Style
// Smooth physics simulation with proper object attraction

(function() {
    'use strict';

    class AntigravityEngine {
        constructor() {
            this.objects = [];
            this.mouse = { x: 0, y: 0 };
            this.targetMouse = { x: 0, y: 0 };
            this.gravity = 0.2;
            this.animationId = null;
            this.container = null;
            this.isRunning = false;
        }

        init() {
            this.container = document.querySelector('.hero-section');
            if (!this.container) {
                console.warn('Hero section not found');
                return;
            }

            // Wait a bit for container to be ready
            setTimeout(() => {
                this.createObjects();
                this.bindEvents();
                this.animate();
                this.isRunning = true;
            }, 100);
        }

        createObjects() {
            if (!this.container) return;

            // Clear existing objects
            this.objects.forEach(obj => {
                if (obj.element && obj.element.parentNode) {
                    obj.element.parentNode.removeChild(obj.element);
                }
            });
            this.objects = [];

            const objectCount = 30;
            const icons = [
                'bi-briefcase-fill',
                'bi-building',
                'bi-person-badge-fill',
                'bi-file-earmark-text-fill',
                'bi-graph-up-arrow',
                'bi-trophy-fill',
                'bi-star-fill',
                'bi-heart-fill',
                'bi-lightbulb-fill',
                'bi-rocket-takeoff-fill',
                'bi-check-circle-fill',
                'bi-award-fill'
            ];

            const colors = [
                '#4285F4', '#EA4335', '#FBBC04', '#34A853',
                '#FF6D01', '#9C27B0', '#00BCD4', '#E91E63',
                '#FF5722', '#009688', '#3F51B5', '#795548'
            ];

            const containerRect = this.container.getBoundingClientRect();

            for (let i = 0; i < objectCount; i++) {
                const element = document.createElement('div');
                element.className = 'antigravity-object';
                
                const icon = document.createElement('i');
                const iconClass = icons[Math.floor(Math.random() * icons.length)];
                icon.className = `bi ${iconClass}`;
                element.appendChild(icon);

                // Size
                const size = 35 + Math.random() * 45;
                element.style.width = size + 'px';
                element.style.height = size + 'px';
                element.style.fontSize = (size * 0.65) + 'px';

                // Color
                const color = colors[Math.floor(Math.random() * colors.length)];
                element.style.color = color;
                element.style.opacity = 0.7 + Math.random() * 0.3;

                // Physics properties
                const obj = {
                    element: element,
                    x: Math.random() * containerRect.width,
                    y: Math.random() * (containerRect.height * 0.4), // Start in upper area
                    vx: (Math.random() - 0.5) * 1.5,
                    vy: Math.random() * 1.5,
                    size: size,
                    mass: size / 25,
                    bounce: 0.75,
                    friction: 0.985
                };

                // Initial position
                element.style.left = obj.x + 'px';
                element.style.top = obj.y + 'px';

                this.container.appendChild(element);
                this.objects.push(obj);
            }
        }

        bindEvents() {
            // Mouse tracking
            document.addEventListener('mousemove', (e) => {
                const rect = this.container.getBoundingClientRect();
                this.targetMouse.x = e.clientX - rect.left;
                this.targetMouse.y = e.clientY - rect.top;
            });

            // Window resize
            let resizeTimeout;
            window.addEventListener('resize', () => {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(() => {
                    this.createObjects();
                }, 250);
            });
        }

        updateObject(obj) {
            const containerRect = this.container.getBoundingClientRect();
            const width = containerRect.width;
            const height = containerRect.height;

            // Calculate distance to mouse
            const dx = this.mouse.x - obj.x;
            const dy = this.mouse.y - obj.y;
            const distance = Math.sqrt(dx * dx + dy * dy);

            // Antigravity attraction force
            const maxDistance = 250;
            if (distance < maxDistance && distance > 10) {
                const forceStrength = (maxDistance - distance) / maxDistance;
                const force = forceStrength * 0.8;
                const angle = Math.atan2(dy, dx);
                
                obj.vx += Math.cos(angle) * force / obj.mass;
                obj.vy += Math.sin(angle) * force / obj.mass;
            }

            // Apply gravity
            obj.vy += this.gravity;

            // Update position
            obj.x += obj.vx;
            obj.y += obj.vy;

            // Apply friction
            obj.vx *= obj.friction;
            obj.vy *= obj.friction;

            // Boundary collisions
            const halfSize = obj.size / 2;
            
            if (obj.x < halfSize) {
                obj.x = halfSize;
                obj.vx *= -obj.bounce;
            } else if (obj.x > width - halfSize) {
                obj.x = width - halfSize;
                obj.vx *= -obj.bounce;
            }

            if (obj.y < halfSize) {
                obj.y = halfSize;
                obj.vy *= -obj.bounce;
            } else if (obj.y > height - halfSize) {
                obj.y = height - halfSize;
                obj.vy *= -obj.bounce;
                obj.vx *= 0.85; // Ground friction
            }

            // Update DOM
            obj.element.style.left = (obj.x - halfSize) + 'px';
            obj.element.style.top = (obj.y - halfSize) + 'px';

            // 3D rotation
            const speed = Math.sqrt(obj.vx * obj.vx + obj.vy * obj.vy);
            const rotX = obj.vy * 1.5;
            const rotY = obj.vx * 1.5;
            const rotZ = (obj.vx + obj.vy) * 1.2;

            // Scale based on mouse proximity
            const mouseDist = distance;
            const scale = mouseDist < 120 ? 1.2 : (mouseDist < 200 ? 1.1 : 1.0);

            obj.element.style.transform = `
                translate3d(0, 0, 0)
                rotateX(${rotX}deg)
                rotateY(${rotY}deg)
                rotateZ(${rotZ}deg)
                scale(${scale})
            `;

            // Opacity based on speed
            const baseOpacity = 0.6;
            const speedOpacity = Math.min(0.4, speed * 0.1);
            obj.element.style.opacity = baseOpacity + speedOpacity;
        }

        animate() {
            if (!this.isRunning) return;

            // Smooth mouse interpolation
            this.mouse.x += (this.targetMouse.x - this.mouse.x) * 0.2;
            this.mouse.y += (this.targetMouse.y - this.mouse.y) * 0.2;

            // Update all objects
            this.objects.forEach(obj => {
                this.updateObject(obj);
            });

            this.animationId = requestAnimationFrame(() => this.animate());
        }

        destroy() {
            this.isRunning = false;
            if (this.animationId) {
                cancelAnimationFrame(this.animationId);
            }
            this.objects.forEach(obj => {
                if (obj.element && obj.element.parentNode) {
                    obj.element.parentNode.removeChild(obj.element);
                }
            });
            this.objects = [];
        }
    }

    // Initialize
    let engine = null;

    function init() {
        if (engine) {
            engine.destroy();
        }
        engine = new AntigravityEngine();
        engine.init();
    }

    // Wait for DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Reinitialize on page show (for browser back/forward)
    window.addEventListener('pageshow', (e) => {
        if (e.persisted) {
            setTimeout(init, 100);
        }
    });

})();
