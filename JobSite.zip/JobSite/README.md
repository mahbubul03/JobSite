# UNIJOB-BD - Job Portal Website

A comprehensive job portal website built with Django, HTML, CSS, and Bootstrap. UNIJOB-BD connects job seekers with employers in Bangladesh.

## Features

### For Job Seekers
- Browse and search job listings
- Apply for jobs with cover letter and resume
- Applicant dashboard to track applications
- Job preparation resources (CV, Cover Letter, Interview tips)
- User-friendly search and filter options

### For Employers
- Post job listings
- Employer dashboard to manage postings
- View applications
- Company profile management

### General Features
- User authentication (Login/Register)
- Responsive design with Bootstrap 5
- Modern and clean UI
- Job categories and filtering
- Contact form
- About Us page

## Technology Stack

- **Backend**: Django 4.2+
- **Frontend**: HTML5, CSS3, Bootstrap 5
- **Database**: SQLite (default, can be changed to PostgreSQL/MySQL)
- **Icons**: Bootstrap Icons

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd JobSite
   ```

2. **Create a virtual environment**
   ```bash
   python -m venv venv
   ```

3. **Activate the virtual environment**
   - On Windows:
     ```bash
     venv\Scripts\activate
     ```
   - On Linux/Mac:
     ```bash
     source venv/bin/activate
     ```

4. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

5. **Run migrations**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

6. **Create a superuser (optional)**
   ```bash
   python manage.py createsuperuser
   ```

7. **Run the development server**
   ```bash
   python manage.py runserver
   ```

8. **Access the website**
   - Open your browser and go to: `http://127.0.0.1:8000/`
   - Admin panel: `http://127.0.0.1:8000/admin/`

## Project Structure

```
JobSite/
├── manage.py
├── requirements.txt
├── README.md
├── unijob_bd/          # Main project settings
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
├── jobs/               # Jobs app
│   ├── models.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   └── ...
├── accounts/           # Accounts app
│   ├── views.py
│   ├── urls.py
│   └── ...
├── templates/          # HTML templates
│   ├── base.html
│   ├── jobs/
│   └── accounts/
└── static/             # Static files
    └── css/
        └── style.css
```

## Pages

- **Home**: Landing page with recent jobs and statistics
- **About Us**: Information about UNIJOB-BD
- **Search Jobs**: Advanced job search with filters
- **Job Listings**: Browse all available jobs
- **Job Detail**: Detailed view of a specific job
- **Submit Job**: Post a new job (Employers only)
- **Employer Dashboard**: Manage job postings and applications
- **Applicant Dashboard**: Track job applications
- **Job Preparation**: Resources for CV, Cover Letter, and Interview
- **Contact**: Contact form and information
- **Login/Register**: User authentication

## Usage

### For Job Seekers
1. Register as an "Applicant"
2. Complete your profile
3. Browse jobs or use search
4. Apply for jobs with cover letter and resume
5. Track applications in your dashboard

### For Employers
1. Register as an "Employer"
2. Complete company profile
3. Post job listings
4. View and manage applications
5. Track job postings in dashboard

## Admin Panel

Access the Django admin panel at `/admin/` to:
- Manage job categories
- View all jobs and applications
- Manage users, employers, and applicants
- Configure site settings

## Development

### Making Changes
- Models are in `jobs/models.py`
- Views are in `jobs/views.py` and `accounts/views.py`
- Templates are in `templates/` directory
- Static files are in `static/` directory

### Database
- Default database is SQLite (`db.sqlite3`)
- To use PostgreSQL or MySQL, update `settings.py` DATABASES configuration

## License

This project is open source and available for educational purposes.

## Contact

For questions or support, please contact: info@unijob-bd.com

---

**UNIJOB-BD** - Your Career Partner in Bangladesh

