# Troubleshooting Guide - UNIJOB-BD

## Common Issues and Solutions

### 1. Server Won't Start

**Error: "ModuleNotFoundError" or Import Errors**
- Make sure you're in the project directory: `cd JobSite`
- Activate your virtual environment (if using one)
- Install dependencies: `pip install -r requirements.txt`

**Error: "No module named 'unijob_bd'"**
- Make sure you're running commands from the directory containing `manage.py`
- Check that `unijob_bd` folder exists in the project root

**Error: "Table doesn't exist"**
- Run migrations: `python manage.py migrate`

### 2. Static Files Not Loading

- Make sure `static/css/style.css` exists
- Run: `python manage.py collectstatic`
- Check `STATICFILES_DIRS` in `settings.py`

### 3. Template Errors

**Error: "TemplateDoesNotExist"**
- Check that `templates` folder exists in project root
- Verify `TEMPLATES` setting in `settings.py` includes `BASE_DIR / 'templates'`

### 4. Database Errors

**Error: "no such table"**
- Run: `python manage.py makemigrations`
- Then: `python manage.py migrate`

### 5. Port Already in Use

**Error: "That port is already in use"**
- Use a different port: `python manage.py runserver 8001`
- Or find and kill the process using port 8000

## Quick Start Commands

```bash
# 1. Navigate to project directory
cd JobSite

# 2. Install dependencies (if not done)
pip install -r requirements.txt

# 3. Run migrations
python manage.py makemigrations
python manage.py migrate

# 4. Create superuser (optional)
python manage.py createsuperuser

# 5. Run server
python manage.py runserver

# 6. Open browser
# Go to: http://127.0.0.1:8000/
```

## Testing the Setup

Run these commands to verify everything is working:

```bash
# Check for configuration errors
python manage.py check

# Verify migrations
python manage.py showmigrations

# Test server (should start without errors)
python manage.py runserver
```

## Getting Help

If you're still having issues:
1. Check the error message in the terminal
2. Make sure all files are in the correct locations
3. Verify Python and Django versions:
   - `python --version` (should be 3.8+)
   - `python -m django --version` (should be 4.2+)

