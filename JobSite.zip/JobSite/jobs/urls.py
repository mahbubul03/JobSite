from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about_us, name='about'),
    path('jobs/', views.job_listings, name='job_listings'),
    path('search/', views.search_jobs, name='search_jobs'),
    path('job/<int:job_id>/', views.job_detail, name='job_detail'),
    path('job/<int:job_id>/apply/', views.apply_job, name='apply_job'),
    path('submit-job/', views.submit_job, name='submit_job'),
    path('employer/dashboard/', views.employer_dashboard, name='employer_dashboard'),
    path('applicant/dashboard/', views.applicant_dashboard, name='applicant_dashboard'),
    path('resources/', views.job_preparation_resources, name='job_preparation'),
    path('contact/', views.contact, name='contact'),
]

