from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from .models import Job, JobCategory, Employer, Applicant, JobApplication


def home(request):
    """Homepage view"""
    recent_jobs = Job.objects.filter(is_active=True)[:6]
    categories = JobCategory.objects.all()[:8]
    total_jobs = Job.objects.filter(is_active=True).count()
    
    context = {
        'recent_jobs': recent_jobs,
        'categories': categories,
        'total_jobs': total_jobs,
    }
    return render(request, 'jobs/home.html', context)


def about_us(request):
    """About Us page"""
    return render(request, 'jobs/about.html')


def job_listings(request):
    """Job listings page with filters"""
    jobs = Job.objects.filter(is_active=True)
    categories = JobCategory.objects.all()
    
    # Filtering
    category_filter = request.GET.get('category')
    job_type_filter = request.GET.get('job_type')
    location_filter = request.GET.get('location')
    search_query = request.GET.get('search')
    
    if category_filter:
        jobs = jobs.filter(category_id=category_filter)
    if job_type_filter:
        jobs = jobs.filter(job_type=job_type_filter)
    if location_filter:
        jobs = jobs.filter(location__icontains=location_filter)
    if search_query:
        jobs = jobs.filter(
            Q(title__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(location__icontains=search_query)
        )
    
    context = {
        'jobs': jobs,
        'categories': categories,
        'selected_category': category_filter,
        'selected_job_type': job_type_filter,
        'selected_location': location_filter,
        'search_query': search_query,
    }
    return render(request, 'jobs/job_listings.html', context)


def search_jobs(request):
    """Search jobs page"""
    jobs = Job.objects.filter(is_active=True)
    categories = JobCategory.objects.all()
    
    search_query = request.GET.get('q', '')
    category_filter = request.GET.get('category')
    job_type_filter = request.GET.get('job_type')
    location_filter = request.GET.get('location')
    
    if search_query:
        jobs = jobs.filter(
            Q(title__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(location__icontains=search_query)
        )
    if category_filter:
        jobs = jobs.filter(category_id=category_filter)
    if job_type_filter:
        jobs = jobs.filter(job_type=job_type_filter)
    if location_filter:
        jobs = jobs.filter(location__icontains=location_filter)
    
    context = {
        'jobs': jobs,
        'categories': categories,
        'search_query': search_query,
        'selected_category': category_filter,
        'selected_job_type': job_type_filter,
        'selected_location': location_filter,
    }
    return render(request, 'jobs/search_jobs.html', context)


def job_detail(request, job_id):
    """Job detail page"""
    job = get_object_or_404(Job, id=job_id, is_active=True)
    has_applied = False
    
    if request.user.is_authenticated:
        try:
            applicant = Applicant.objects.get(user=request.user)
            has_applied = JobApplication.objects.filter(job=job, applicant=applicant).exists()
        except Applicant.DoesNotExist:
            pass
    
    context = {
        'job': job,
        'has_applied': has_applied,
    }
    return render(request, 'jobs/job_detail.html', context)


@login_required
def employer_dashboard(request):
    """Employer dashboard"""
    try:
        employer = Employer.objects.get(user=request.user)
        jobs = Job.objects.filter(employer=employer)
        total_applications = JobApplication.objects.filter(job__employer=employer).count()
        
        context = {
            'employer': employer,
            'jobs': jobs,
            'total_applications': total_applications,
        }
        return render(request, 'jobs/employer_dashboard.html', context)
    except Employer.DoesNotExist:
        messages.warning(request, 'Please complete your employer profile first.')
        return redirect('home')


@login_required
def applicant_dashboard(request):
    """Applicant dashboard"""
    try:
        applicant = Applicant.objects.get(user=request.user)
        applications = JobApplication.objects.filter(applicant=applicant)
        
        context = {
            'applicant': applicant,
            'applications': applications,
        }
        return render(request, 'jobs/applicant_dashboard.html', context)
    except Applicant.DoesNotExist:
        messages.warning(request, 'Please complete your applicant profile first.')
        return redirect('home')


@login_required
def submit_job(request):
    """Submit a new job posting"""
    if request.method == 'POST':
        try:
            employer = Employer.objects.get(user=request.user)
            
            job = Job.objects.create(
                title=request.POST.get('title'),
                employer=employer,
                category_id=request.POST.get('category'),
                description=request.POST.get('description'),
                requirements=request.POST.get('requirements'),
                location=request.POST.get('location'),
                job_type=request.POST.get('job_type'),
                experience_level=request.POST.get('experience_level'),
                salary_min=request.POST.get('salary_min') or None,
                salary_max=request.POST.get('salary_max') or None,
                application_deadline=request.POST.get('application_deadline'),
            )
            
            messages.success(request, 'Job posted successfully!')
            return redirect('employer_dashboard')
        except Employer.DoesNotExist:
            messages.error(request, 'Please complete your employer profile first.')
            return redirect('home')
    
    categories = JobCategory.objects.all()
    context = {
        'categories': categories,
    }
    return render(request, 'jobs/submit_job.html', context)


@login_required
def apply_job(request, job_id):
    """Apply for a job"""
    job = get_object_or_404(Job, id=job_id, is_active=True)
    
    try:
        applicant = Applicant.objects.get(user=request.user)
    except Applicant.DoesNotExist:
        messages.error(request, 'Please complete your applicant profile first.')
        return redirect('home')
    
    if request.method == 'POST':
        if JobApplication.objects.filter(job=job, applicant=applicant).exists():
            messages.warning(request, 'You have already applied for this job.')
            return redirect('job_detail', job_id=job_id)
        
        application = JobApplication.objects.create(
            job=job,
            applicant=applicant,
            cover_letter=request.POST.get('cover_letter'),
            resume=request.FILES.get('resume'),
        )
        
        messages.success(request, 'Application submitted successfully!')
        return redirect('applicant_dashboard')
    
    context = {
        'job': job,
    }
    return render(request, 'jobs/apply_job.html', context)


def job_preparation_resources(request):
    """Job preparation resources page"""
    return render(request, 'jobs/job_preparation.html')


def contact(request):
    """Contact page"""
    if request.method == 'POST':
        # Handle contact form submission
        messages.success(request, 'Thank you for contacting us! We will get back to you soon.')
        return redirect('contact')
    
    return render(request, 'jobs/contact.html')

