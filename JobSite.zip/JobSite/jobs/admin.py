from django.contrib import admin
from .models import JobCategory, Employer, Applicant, Job, JobApplication


@admin.register(JobCategory)
class JobCategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'created_at']
    search_fields = ['name']


@admin.register(Employer)
class EmployerAdmin(admin.ModelAdmin):
    list_display = ['company_name', 'user', 'phone', 'created_at']
    search_fields = ['company_name', 'user__username']


@admin.register(Applicant)
class ApplicantAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'user', 'phone', 'created_at']
    search_fields = ['full_name', 'user__username']


@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ['title', 'employer', 'category', 'location', 'job_type', 'is_active', 'created_at']
    list_filter = ['job_type', 'is_active', 'category', 'created_at']
    search_fields = ['title', 'description', 'location']
    date_hierarchy = 'created_at'


@admin.register(JobApplication)
class JobApplicationAdmin(admin.ModelAdmin):
    list_display = ['job', 'applicant', 'status', 'applied_at']
    list_filter = ['status', 'applied_at']
    search_fields = ['job__title', 'applicant__full_name']

